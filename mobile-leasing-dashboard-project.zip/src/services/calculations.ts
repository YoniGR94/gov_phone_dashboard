import type { ChartPoint, Device, GradeBand, TerminationRule } from '../types';

export function money(value: number): string {
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    maximumFractionDigits: 2,
  }).format(value);
}

export function resolveGradeBand(rank: number, gradeType: string, bands: GradeBand[], mapping?: Record<string, string>): GradeBand {
  const mappedKey = mapping?.[gradeType];
  const byMapping = mappedKey ? bands.find((band) => band.id === mappedKey || band.label === mappedKey) : undefined;
  if (byMapping) return byMapping;

  const matched = bands.find((band) => {
    const minOk = typeof band.minGrade === 'number' ? rank >= band.minGrade : true;
    const maxOk = typeof band.maxGrade === 'number' ? rank <= band.maxGrade : true;
    return minOk && maxOk;
  });

  return matched ?? bands[0];
}

export function calculateMonthlyEmployeeCost(device: Device, band: GradeBand): number {
  return Math.max(device.leaseMonthly - band.employeeContribution, 0);
}

export function calculateMonthlyOfficeCost(device: Device, band: GradeBand): number {
  return Math.min(device.leaseMonthly, band.employeeContribution);
}

export function calculateTotal24Months(device: Device, band: GradeBand): number {
  return calculateMonthlyEmployeeCost(device, band) * 24 + device.buyoutEnd;
}

export function calculateExitCost(device: Device, month: number, band: GradeBand): number {
  const employeeMonthly = calculateMonthlyEmployeeCost(device, band);
  const totalPaid = employeeMonthly * month;
  const remaining = Math.max(device.weightedListPrice - totalPaid, 0);
  return month >= 24 ? device.buyoutEnd : remaining;
}

export function buildChartData(device: Device, band: GradeBand): ChartPoint[] {
  return Array.from({ length: 24 }, (_, idx) => {
    const month = idx + 1;
    const employeeMonthly = calculateMonthlyEmployeeCost(device, band);
    const officeMonthly = calculateMonthlyOfficeCost(device, band);
    return {
      month,
      employeeMonthly,
      officeMonthly,
      cumulativeEmployee: employeeMonthly * month,
      exitCost: calculateExitCost(device, month, band),
      buyoutAtEnd: device.buyoutEnd,
    };
  });
}

export function applyTerminationRule(
  device: Device,
  month: number,
  band: GradeBand,
  rules: TerminationRule[]
): string {
  const scenario = month < 24 ? 'early_exit' : 'end_of_lease';
  const rule = rules.find((r) => r.scenario === scenario);
  if (!rule) {
    return `No rule found for ${scenario}.`;
  }

  const cost = month < 24 ? calculateExitCost(device, month, band) : device.buyoutEnd;
  return `${rule.description}: ${money(cost)}.`;
}
