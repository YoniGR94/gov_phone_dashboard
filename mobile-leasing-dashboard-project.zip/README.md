# Mobile Leasing Dashboard

React + TypeScript dashboard for simulating government mobile leasing costs.

## Run locally

```bash
npm install
npm run dev
```

## Data

Device data is loaded from:

- `public/data/devices.json`
- `public/data/gradeBands.json`
- `public/data/mappings.json`
- `public/data/terminationRules.json`

Replace these files with your real tables when ready.
